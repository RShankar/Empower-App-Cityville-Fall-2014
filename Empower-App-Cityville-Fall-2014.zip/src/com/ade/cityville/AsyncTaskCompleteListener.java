package com.ade.cityville;

public interface AsyncTaskCompleteListener<T> {
	public void onTaskComplete(T result);
}
